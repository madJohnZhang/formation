#include <dji_sdk/dji_sdk.h>

#include <iostream>
#include <fstream>
#include <ctime>
#include <vector>
#include <queue>
#include <thread>
#include <cassert>
//#include<opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>

#include <serial/serial.h>
#include <ros/ros.h>
#include <thread>
#include <mutex>
#include <sys/time.h>

#include "DJI_guidance.h"
#include "DJI_utility.h"

#include <djiosdk/dji_broadcast.hpp>

#include <geometry_msgs/TransformStamped.h> //IMU
#include <geometry_msgs/Vector3Stamped.h>   //velocity
#include <sensor_msgs/LaserScan.h>          //obstacle distance & ultrasonic
#include <sensor_msgs/CameraInfo.h>         // camera info message. Contains cam params
#include "yaml-cpp/yaml.h"                  // use to parse YAML calibration file
#include <fstream>                          // required to parse YAML

//#include"inc2/trackOnUav.h"
#include "inc/tracker.cpp"
#include "detector.h"
#include "PID.h"
#include "Kalman.h"
#include "trajectory.h"
#include "obs.hpp"

#include "formation.cpp"

//#define CONTROL

using namespace std;
using namespace ros;
using namespace cv;
using namespace DJI::OSDK;

mutex mtxCam;
Mat frame;

void getFrame(VideoCapture *cap)
{
    while (true)
    {
        mtxCam.lock();
        *cap >> frame;
        mtxCam.unlock();
    }
}

long long getSystemTime()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000000 + tv.tv_usec;
}

int main(int argc, char **argv)
{

    /*FileStorage fs("formation.xml",FileStorage::WRITE);
    fs<<"formationNum"<<3;
    fs<<"seq"<<1;
    string port("/dev/ttyUSB1");
    fs<<"port"<<port;
    fs<<"baudrate"<<9600;
    Mat topo = (Mat_<int>(3,3)<< 1,1,1,0,1,0,1,0,0,0,0,1);
    Mat coefficients = (Mat_<float>(2,4)<<1,1,0,0,0,0,1,1);
    fs<<"topology"<<topo;
    fs<<"coefficients"<<coefficients;
    Mat f = (Mat_<float>(4,2) << -2.5, 2.5, 0, 0, 0, 0, 0, 0);
    fs<<"formation"<<f;
    fs.release();*/
    init(argc, argv, "main");
    NodeHandle nh;
    Formation formation(1, argv);
    int calibration = 1;
    cout << "please input the cali mode: not 0 for calibration completed; 0, do calibration" << endl;
    cin >> calibration;

    formation.cali(calibration);
    cout << "cali complete press any button to continue." << endl;
    getchar();

    fstream dataSelf("dataSelf.csv", ios::trunc | ios::out);
    fstream dataXb("dataXb.csv", ios::trunc | ios::out);
    dataSelf << "latitude,"
             << "longitude,"
             << "yaw" << endl;
    dataXb << "number,"
           << "latitude,"
           << "longitude,"
           << "yaw" << endl;

    Detector target_finder(argc, argv);
    StapleTracker visual_tracker;
    Kalman motion_estimator;
    Trajectory traj_generator;
    PID controller;
    //LEDcontroller led;
    const float con_gain = 0.3; //the impact of the control signals on the EKF
    queue<float> q_vx, q_vy, q_vz, q_vyaw;
    fstream log_file("log_date.log", ios::trunc | ios::out);
    fstream log_pos("log_pos.csv", ios::trunc | ios::out);
    clock_t timer, timer_fps;
    long long timer_ts;
    char name[64];
    timer = clock();
    int iterate_times = 0;
    bool target_lost = false;

    vector<int> bounding_box(4);
    Mat image;
    VideoCapture cap;
    //Mat frame;
    cap.open(0);
    if (!cap.isOpened())
    {
        log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " cannot open camera!" << endl;
        return 0;
    }
    else
    {
        log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " camera opened" << endl;
    }
    //thread thread_video(getFrame, &cap);

    //ser.open();
    //string read;
    /*while(1)
    {
	ser.read(read, 4);
	cout<<read<<endl;
	sleep(1000);
    }*/
    //first frame init
    waitKey(10);
    cap >> frame;
    frame.copyTo(image);
    while (!target_finder.find(image))
    {
        cap >> frame;
        frame.copyTo(image);
    }
    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " target found" << endl;
    //led.on();
    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " start tracking init" << endl;
    //init tracker
    visual_tracker.init(image, target_finder.bounding_box());
    //init EKF
    motion_estimator.init(visual_tracker.position(), true);
    //init trajectory
    traj_generator.init(motion_estimator.position());

    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " init tracker" << endl;
    log_pos << visual_tracker.position()[0] << "," << visual_tracker.position()[1] << "," << visual_tracker.position()[2] << ",";

    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " init kalman" << endl;
    log_pos << motion_estimator.position()[0] << "," << motion_estimator.position()[1] << "," << motion_estimator.position()[2] << ",";

    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " init traj_gen" << endl;
    log_pos << traj_generator.position()[0] << "," << traj_generator.position()[1] << "," << traj_generator.position()[2] << "," << traj_generator.position()[2] << endl;

#ifdef CONTROL

    Vehicle *vehicle = formation.getVehicle();
    formation.initVehicle();
    //init PID
    controller.init("para.txt");
    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " start main tracking loop" << endl;

    //init Guidance
    //initObs(10, 0.03);
#endif
    timer_ts = getSystemTime();
    timer_fps = clock();
    ros::Rate loop_rate(10);
    //main loop
    while (ros::ok())
    {
        loop_rate.sleep();
        ros::spinOnce();
        cap >> frame;
        cout << "here1" << endl;
        frame.copyTo(image);
        target_lost = !visual_tracker.track(image);
        if (target_lost)
        {
            log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " target lost!" << endl;
        }
        /*
	if(!visual_tracker.track(image)){
            //led.off();
            log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " target lost" << endl;
            while(!target_finder.find(image)){
                frame.copyTo(image);
                drone->attitude_control(0x48,0,0,0,0);
            }
            log_file<<(clock() - timer)/(float)CLOCKS_PER_SEC<<" target found"<<endl;
            //led.on();
            visual_tracker.init(image,target_finder.bounding_box());
            motion_estimator.init(visual_tracker.position(),true);
        }
*/
        cout << "here2" << endl;
        if (!(iterate_times % 8) /*&&!target_lost*/) //templates update frequency
        {
            visual_tracker.update(image);
        }
        visual_tracker.drawCurrentImg(image);
        //imshow("Tracking API", image);
        log_pos << visual_tracker.position()[0] << "," << visual_tracker.position()[1] << "," << visual_tracker.position()[2] << ",";

//montion estimator
#ifdef CONTROL
        if (vehicle->broadcast->getRC().gear == -4545 && q_vx.size() > 7)
        { //size of control signal buffer
            motion_estimator.update(visual_tracker.position(), q_vx.front() * con_gain, q_vy.front() * con_gain, q_vz.front() * con_gain, q_vyaw.front() * 3.14159 / 180.0 * con_gain, getSystemTime() - timer_ts);
            q_vx.pop();
            q_vy.pop();
            q_vz.pop();
            q_vyaw.pop();
        }
        else
#endif
        {
            motion_estimator.update(visual_tracker.position(), 0, 0, 0, 0, getSystemTime() - timer_ts);
        }
        log_pos << ","
                << "motion estimate"
                << "," << motion_estimator.position()[0] << "," << motion_estimator.position()[1] << "," << motion_estimator.position()[2] << ",";
        timer_ts = getSystemTime();
        cout << "here3" << endl;

        vector<double> formationInput(2, 0);
        if (Formation::count <= SERIES)
        {
            formation.init();
        }
        else
        {
            Mat tmp = formation.getInput();
            formationInput[0] = tmp.at<double>(0);
            formationInput[1] = tmp.at<double>(1);
            cout << "formationinput" << formationInput[0] << " " << formationInput[1] << endl;
        }
        formation.print(&dataSelf, &dataXb);

        //trajectory generator
        //obstacle input removed temporarily
        //vector<float> obs_input = getAvoidanceInput();
        traj_generator.generate(motion_estimator.position(), formationInput);
        log_pos << ","
                << "traj_generator"
                << "," << traj_generator.position()[0] << "," << traj_generator.position()[1] << "," << traj_generator.position()[2] << "," << traj_generator.position()[3];

#ifdef CONTROL
        //PID controller and UAV communicator
        Control::CtrlData conInput(Control::STABLE_ENABLE | Control::HORIZONTAL_BODY | Control::HORIZONTAL_VELOCITY | Control::VERTICAL_POSITION, 0, 0, 2, 0);
        if (vehicle->broadcast->getRC().gear == -4545)
        {
            controller.update(traj_generator.position());
            log_pos << ","
                    << "control signal"
                    << "," << controller.vx << "," << controller.vy << "," << controller.vz << "," << controller.vyaw << endl;
            q_vx.push(controller.vx);
            q_vy.push(controller.vy);
            q_vz.push(controller.vz);
            q_vyaw.push(controller.vyaw);
            cout << "obs input is: " << controller.vy << endl;
            conInput = Control::CtrlData(0x4A, controller.vx, controller.vy, controller.vz, controller.vyaw); //controller.vz
        }
        else
        {
            log_pos << endl;
            controller.init("para.txt");
        }
        vehicle->control->flightCtrl(conInput);
        cout << "here4" << endl;
#endif
#ifndef CONTROL
        log_pos << endl;
#endif
        if (!(iterate_times % 50))
        { //image output rate
            vector<int> param = vector<int>(2);
            sprintf(name, "%03d.jpg", iterate_times);
            param[0] = CV_IMWRITE_JPEG_QUALITY;
            param[1] = 95;
            imwrite(name, image, param);
        }
        //write log before & after every step
        iterate_times++;
        log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " All right, " << (float)(CLOCKS_PER_SEC * iterate_times) / (clock() - timer_fps) << "fps" << endl;
        //waitKey();
    }
    //main loop end

#ifdef CONTROL
    vehicle->releaseCtrlAuthority(10);
#endif
    /* release data transfer */
    int err_code = stop_transfer();
    RETURN_IF_ERR(err_code);
    //make sure the ack packet from GUIDANCE is received
    sleep(1);
    std::cout << "release_transfer" << std::endl;
    err_code = release_transfer();
    RETURN_IF_ERR(err_code);
    log_file << (clock() - timer) / (float)CLOCKS_PER_SEC << " end tracking" << endl;
    return 0;
}
